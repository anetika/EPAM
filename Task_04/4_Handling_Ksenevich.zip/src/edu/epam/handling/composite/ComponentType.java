package edu.epam.handling.composite;

public enum ComponentType {
    TEXT, PARAGRAPH, SENTENCE, LEXEME, WORD, PUNCTUATION, LETTER
}
