package edu.epam.entity;

public enum RequiredAction {
    LOAD, UNLOAD
}
