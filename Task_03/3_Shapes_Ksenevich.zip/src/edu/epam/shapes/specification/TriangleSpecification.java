package edu.epam.shapes.specification;

import edu.epam.shapes.entity.Triangle;

public interface TriangleSpecification {
    boolean specified(Triangle triangle);
}
