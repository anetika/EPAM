package edu.epam.parsing.entity;

public enum DepositType {
    ON_DEMAND, TERM, CALCULATED, ACCUMULATIVE, SAVING, METALLIC;
}
